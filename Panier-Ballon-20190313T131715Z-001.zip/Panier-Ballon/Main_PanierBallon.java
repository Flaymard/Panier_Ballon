public class Main_PanierBallon {
	
	public static void main (String[] args) {
		TestTrajectoire tt = new TestTrajectoire();
	}
    
    // on met l'interface 
    // creation d'un ballon
    // creation d'un panier
    // score 
    // timer
}

